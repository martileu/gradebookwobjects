import java.awt.event.InputMethodListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.junit.jupiter.params.shadow.com.univocity.parsers.annotations.Parsed;

public class Gradebook {
	public static void main(String[] args) throws FileNotFoundException{
		File inputFile = new File("gradebookData.txt"); 
		//reads the file
		Scanner input = new Scanner(inputFile);		
		String studentName= input.nextLine();
		//loops thru the input file 
		while (!studentName.equals("end")) {
			int numHw=Integer.parseInt(input.nextLine());
			
			double[] hwScores=new double[numHw];
			for (int i=0; i<numHw; i++) {
				hwScores[i]= Double.parseDouble(input.nextLine());
			
			double[] hwPossScores=new double[numHw];
			for (int j=0; j<numHw; j++) {
				hwPossScores[j]= Double.parseDouble(input.nextLine());
			}
			input.nextLine(); //midterm
			double midtermScore = Double.parseDouble(input.nextLine());
			double midtermPossScore=Double.parseDouble(input.nextLine());
			input.nextLine();//final
			double finalScore = Double.parseDouble(input.nextLine());
			double finalPossScore =Double.parseDouble(input.nextLine());
			
			Student stu = new Student(studentName, hwScores, hwPossScores, midtermScore, midtermPossScore, finalScore,finalPossScore);
			System.out.println(stu.toString());
			studentName=input.nextLine();
			}
		
		}
			
		
}
}


	
