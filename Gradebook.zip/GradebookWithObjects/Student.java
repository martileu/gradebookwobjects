import java.io.ObjectInputStream.GetField;

import org.junit.validator.PublicClassValidator;

public class Student {
	private String name;
	private double[] hwScores;
	private double[] hwPossibleScores;
	private double midtermScore;
	private double midtermPossibleScore;
	private double finalScore;
	private double finalPossibleScore;
	
	public Student(String n, double[] hw, double[] hwposs, double md, double mdposs, double f, double fposs) {
	name=n;
	hwScores=hw;
	hwPossibleScores=hwposs;
	midtermScore=md;
	midtermPossibleScore=mdposs;
	finalScore=f;
	finalPossibleScore=fposs;
	}
	public static double round2(double number) {
		double answerRound = 0;
		if (number>=0) {
			answerRound= (((number*1000) + 5)/10);
			int intRound= (int)(answerRound);
			answerRound = ((double)intRound/100);
		}else if (number<0) {
			answerRound=(((number*1000)-5)/10);
			int intRound= (int)(answerRound);
			answerRound=((double)intRound/100);
		}
		return answerRound;
	}

	public static double calcPercent(double part, double whole) {
		double percent=(part/whole)*100;
		return round2(percent);
	}
	//goes thru array to get hw scores total
	public static double getHwTotal(double[] hw) {
		double hwTotal=0;
		for (int i=0; i<hw.length;i++) {
			hwTotal += hw[i];
		}
		return hwTotal;
	}
	//goes thru array to get hw scores total
		public static double getHwPossTotal(double[] hwposs) {
			double hwPossTotal=0;
			for (int i=0; i<hwposs.length;i++) {
				hwPossTotal += hwposs[i];
			}
			return hwPossTotal;
		}
		
	//open fields that calculate the percents using calPercent
	public double hwPercent=calcPercent(getHwTotal(hwScores),getHwPossTotal(hwPossibleScores));
	public double mdPercent=calcPercent(midtermScore, midtermPossibleScore);
	public double finalPercent=calcPercent(finalScore,finalPossibleScore);
	double overallPercent=round2( 0.5*hwPercent+ 0.2*mdPercent+ 0.3*finalPercent);
	
	
	//method that uses the overall percent to find a letter grade
	public static char findGrade(double percent) {
		char letterGrade;
		if (percent>=90) {
			letterGrade = 'A';
		}
		else if (percent>=80) {
			letterGrade = 'B';
		}	
		else if (percent>=70) {
			letterGrade = 'C';
		}	
		else if (percent>=60) {
			letterGrade = 'D';
		}
		else {
			letterGrade = 'F';
		}
		return letterGrade;
	}
	//returns the output with the grades and stuff
	public String toString() {
		String output=name+" /n";
		output+= "Overall = "+round2(overallPercent)+"%, "+findGrade(overallPercent)+"/n";
		output+="Homework = "+hwPercent+"%/n";
		output+="Midterm = "+mdPercent+"%/n";
		output+="Final Exam = "+finalPercent+"%/n/n";
		return output;
		}
}

